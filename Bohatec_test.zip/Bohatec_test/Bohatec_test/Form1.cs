﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bohatec_test
{
    public partial class Form1 : Form
    {
        int g_id = 0; //:DDDDDDDDDDDDD
        List<circle> Circles;
        
        Point g_position = new Point(0, 0);
        public Form1()
        {
            InitializeComponent();
            Circles = new List<circle>();
            for (int i = 0; i < 3; i++)
            {
                circle lol = new circle(g_position.X, g_position.Y, i * 40, 0, 50, Color.Red, g_id);
                Circles.Add(lol);
                g_id += 1;
            }
            for (int i = 0; i < 2; i++)
            {
                circle lol = new circle(g_position.X, g_position.Y, 25 + i * 30, 30, 50, Color.Yellow, g_id);
                Circles.Add(lol);
                g_id += 1;
            }
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {

            foreach (var circle in Circles)
            {
                Pen redBrush = new Pen(circle.Coolor, Convert.ToSingle((numericUpDown3.Value * 12 / 100)));
                e.Graphics.DrawEllipse(redBrush, circle.X, circle.Y, circle.Size, circle.Size);
            }

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox1.Refresh();
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (var circle in Circles)
            {
                if (checkBox1.Checked == false)
                {
                    circle.X = e.X + circle.OffsetX;
                    circle.Y = e.Y + circle.OffsetY;
                    Text = g_id.ToString();
                }
                else
                {
                    Random r_num = new Random();

                    circle.X = r_num.Next(0, Width) + circle.OffsetX;
                    circle.Y = r_num.Next(0, Height) + circle.OffsetY;

                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cd1.ShowDialog();
            circle result = Circles.Find(circle => circle.ID == 1);
            result.Coolor = cd1.Color;
            pictureBox1.Refresh();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            cd1.ShowDialog();
            circle result = Circles.Find(circle => circle.ID == 2);
            result.Coolor = cd1.Color;
            pictureBox1.Refresh();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            cd1.ShowDialog();
            circle result = Circles.Find(circle => circle.ID == 3);
            result.Coolor = cd1.Color;
            pictureBox1.Refresh();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            cd1.ShowDialog();
            circle result = Circles.Find(circle => circle.ID == 4);
            result.Coolor = cd1.Color;
            pictureBox1.Refresh();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            cd1.ShowDialog();
            circle result = Circles.Find(circle => circle.ID == 0);
            result.Coolor = cd1.Color;
            pictureBox1.Refresh();
        }

        private void numericUpDown3_ValueChanged(object sender, EventArgs e)
        {
            foreach (var circle in Circles)
            {
                circle.Size = (int)numericUpDown3.Value;
                pictureBox1.Refresh();
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            cd1.ShowDialog();
            circle result = Circles.Find(circle => circle.ID == 1);
            result.Coolor = cd1.Color;
            pictureBox1.Refresh();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            cd1.ShowDialog();
            circle result = Circles.Find(circle => circle.ID == 2);
            result.Coolor = cd1.Color;
            pictureBox1.Refresh();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            cd1.ShowDialog();
            circle result = Circles.Find(circle => circle.ID == 3);
            result.Coolor = cd1.Color;
            pictureBox1.Refresh();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            cd1.ShowDialog();
            circle result = Circles.Find(circle => circle.ID == 4);
            result.Coolor = cd1.Color;
            pictureBox1.Refresh();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            cd1.ShowDialog();
            circle result = Circles.Find(circle => circle.ID == 0);
            result.Coolor = cd1.Color;
            pictureBox1.Refresh();
        }
    }
}
