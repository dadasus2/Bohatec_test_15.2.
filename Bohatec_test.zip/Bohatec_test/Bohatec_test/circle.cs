﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Bohatec_test
{
    class circle
    {
        public int OffsetX { get; set; }
        public int OffsetY { get; set; }

        public int X { get; set; }
        public int Y { get; set; }

        public int Size { get; set; }

        public Color Coolor { get; set; }

        public int ID { get; set; }

        public circle(int x, int y, int offsetx, int offsety, int size, Color color, int id)
        {
            OffsetX = offsetx;
            OffsetY = offsety;
            X = x;
            Y = y;
            Size = size;
            Coolor = color;
            ID = id;
        }
    }
}